var app = angular.module('keep', []);

app.controller('keepCtrl', function($scope){
	

	$scope.menuAdv = function(menu){
		$scope.menu = menu;

		switch(menu){
			case "temp":
				$scope.titleAdv = "Tempo Real";
				$scope.textAdv = "Controle o budget da sua campanha através dos resultados de performance em tempo real.";
				break;

			case "enga":
				$scope.titleAdv = "Engajamento";
				$scope.textAdv = "Acompanhe o nível de interação com o usuário e entenda o envolvimento do consumidor com a marca para gerar insights de campanha.";
				break;
			case "perf":
				$scope.titleAdv = "Performance";
				$scope.textAdv = "Mensuração dos resultados, acesso as principais métricas, estimativas de retorno e redução das surpresas ou incertezas.";
				break;
			case "data":
				$scope.titleAdv = "Dados";
				$scope.textAdv = "Com a integração dos dados e o acompanhamento em tempo real dos resultados, a tomada de decisão torna-se um processo mais rápido e assertivo.";
				break;
			case "free":
				$scope.titleAdv = "Gratuito";
				$scope.textAdv = "A mudança na maneira de analisar dados e ter uma plataforma que ofereça soluções completas para campanhas digitais é tão necessária que precisa ser democrática e acessível, por isso, a plataforma é totalmente gratuita.";
				break;

		}
	}

	$scope.menuAdv("temp");
})

